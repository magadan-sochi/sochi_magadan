
import React from 'react';

// Registration is handled in an external system.
// This page is no longer used.
const RegisterPage: React.FC = () => {
  return null;
};

export default RegisterPage;
